# Projet d�mo ETL

Ce projet de d�mo est une solution possible au probl�me d'ETL pos� lors des laboratoires. Vous pouvez l'ouvrir avec les SQL Server Data Tools incluant SSIS 11.0.2100.60 (Shell VS2010), version disponible sur les machines de laboratoire de l'IESN. 

Pour pavenir � faire fonctionner ce package SSIS, vous devrez modifier les connection managers pour:
- faire pointer ces derniers vers vos bases de donn�es (�ditez les propri�t�s de la connexion)
- faire pointer le fichier plat des dates vers un fichier existant sur votre disque (fichier disponible dans cette arborescence, cherchez ListeDates.csv).


