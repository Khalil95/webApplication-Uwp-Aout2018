using Microsoft.AspNetCore.Identity;

namespace ProjectUsingDbFirst
{
    public class ApplicationUser:IdentityUser
    {
    }
}