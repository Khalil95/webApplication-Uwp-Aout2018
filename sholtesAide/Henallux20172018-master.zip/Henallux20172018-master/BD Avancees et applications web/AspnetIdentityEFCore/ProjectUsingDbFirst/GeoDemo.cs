﻿using System;
using System.Collections.Generic;

namespace ProjectUsingDbFirst
{
    public partial class GeoDemo
    {
        public int Id { get; set; }
        public string Nom { get; set; }
    }
}
