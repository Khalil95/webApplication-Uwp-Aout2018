﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ToDoDemo.Models
{
    public class ToDoItem
    {
        public long Id { get; set; }
        public string Description { get; set; }
    }
}