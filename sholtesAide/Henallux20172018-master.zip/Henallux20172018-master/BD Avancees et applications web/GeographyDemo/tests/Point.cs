namespace tests
{
    internal struct Point
    {
        public float Latitude;
        public float Longitude;
    }
}