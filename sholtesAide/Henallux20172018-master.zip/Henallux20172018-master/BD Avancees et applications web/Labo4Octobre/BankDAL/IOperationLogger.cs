
namespace BankDAL
{
    public interface IOperationLogger
    {
        void Log(string message);
    }
}